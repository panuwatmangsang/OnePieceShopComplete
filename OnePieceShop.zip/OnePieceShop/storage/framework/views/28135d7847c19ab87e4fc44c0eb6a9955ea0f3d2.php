<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- css -->
    <link rel="stylesheet" href="/css/index2.css">

    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

    <title>One Piece Shop</title>
</head>

<body>
    <header>
        <div class="navbar">
            <div class="logo">
                <a href="<?php echo e(route('index')); ?>"><img src="/images/logo3.png" alt="logo one piece" width="125px"></a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li><a class="active" href="<?php echo e(route('index')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('products')); ?>">Product</a></li>
                    <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                    <li><a href="<?php echo e(route('account')); ?>">Accout</a></li>
                </ul>
            </nav>
            <a href="<?php echo e(route('cart')); ?>"><img src="/images/cart.png" class="nav-cart" width="40px"></a>
        </div>
    </header>

    <section class="header">
        <div class="container">
            <div class="row">
                <div class="col-2">
                    <h1>One Piece Shop</h1>
                    <p>ยินดีต้อนรับสู่ One Piece Shop ร้านค้าที่มีสิ่งของเกี่ยวกับวันพีชให้คุณได้เลือกซื้อมากมาย <br>
                        ไม่ว่าจะเป็น โมเดลวันพีช โปสเตอร์วันพีช เสื้อผ้าวันพีช เครื่องประดับอีกมากมาย <br>
                        ที่เราคัดสรรมาให้คุณโดยเฉพาะ <br>
                        <a href="#" class="btn-explore">Explore Now &#8594;</a>
                    </p>
                </div>
                <div class="col-2">
                    <img src="/images/one-piece-bg.png">
                </div>
            </div>
        </div>
    </section>

    <section class="featured-categories">
        <div class="categories">
            <div class="small-container">
                <div class="row">
                    <div class="col-3">
                        <img src="/images/categories1.png">
                    </div>
                    <div class="col-3">
                        <img src="/images/categories2.png">
                    </div>
                    <div class="col-3">
                        <img src="/images/categories3.jpg">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <!--------------- featured products -------------->
        <div class="small-container">
            <h2 class="title">Featured Products</h2>
            <div class="row">
                <div class="col-4">
                    <img src="/images/model/kaido/kaido.jpg">
                    <h4>Kaido</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>650 THB</p>
                </div>
                <div class="col-4">
                    <img src="/images/model/luffy3/luffy31.jpg">
                    <h4>Luffy</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>900 THB</p>
                </div>
                <div class="col-4">
                    <img src="../images/model/jinbe/jinbe.jpg">
                    <h4>Jinbe</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half-o"></i>
                    </div>
                    <p>1300 THB</p>
                </div>
                <div class="col-4">
                    <img src="/images/model/luffy-catacuri/luffy-catacuri.jpg">
                    <h4>Luffy And Catacuri</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>1250 THB</p>
                </div>
            </div>

            <h2 class="title">Latest Products</h2>
            <div class="row">
                <div class="col-4">
                    <img src="/images/model/kaido/kaido.jpg">
                    <h4>Kaido</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>650 THB</p>
                </div>
                <div class="col-4">
                    <img src="../images/model/jinbe/jinbe.jpg">
                    <h4>Jinbe</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half-o"></i>
                    </div>
                    <p>1300 THB</p>
                </div>
                <div class="col-4">
                    <img src="/images/model/luffy3/luffy31.jpg">
                    <h4>Luffy</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <p>900 THB</p>
                </div>
                <div class="col-4">
                    <img src="/images/model/hancock/hancock.jpg">
                    <h4>Hancock</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>550 THB</p>
                </div>
                <div class="col-4">
                    <img src="/images/accessories/accessories1.jpg" height="240px">
                    <h4>Necklace</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>50 THB</p>
                </div>
                <div class="col-4">
                    <img src="/images/sundry/sundry3.jpg">
                    <h4>Mattress set</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>400 THB</p>
                </div>
                <div class="col-4">
                    <img src="/images/accessories/accessories9.jpg">
                    <h4>Bangle</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <p>30 THB</p>
                </div>
                <div class="col-4">
                    <img src="/images/sundry/bepo3/bepo31.jpg">
                    <h4>ฺBepo</h4>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <p>250 THB</p>
                </div>
            </div>
        </div>
    </section>
    <section></section>

    <footer>

    </footer>
</body>
<script src="<?php echo e(asset('/js/index3.js')); ?>"></script>

</html><?php /**PATH C:\xampp\htdocs\OnePieceShop\OnePieceShop\resources\views/pages/index3.blade.php ENDPATH**/ ?>