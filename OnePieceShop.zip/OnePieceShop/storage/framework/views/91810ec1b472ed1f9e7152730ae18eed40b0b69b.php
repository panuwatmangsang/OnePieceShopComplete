<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- css -->
    <link rel="stylesheet" href="/css/index.css">

    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Alata&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <title>All Products</title>
</head>

<body>
    <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="<?php echo e(route('index')); ?>"><img src="/images/logo3.png" alt="logo one piece" width="125px"></a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li><a class="active" href="<?php echo e(route('index')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('products')); ?>">Product</a></li>
                    <li><a href="<?php echo e(route('about')); ?>">About</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                    <li><a href="<?php echo e(route('account')); ?>">Accout</a></li>
                </ul>
            </nav>
            <a href="<?php echo e(route('cart')); ?>"><i class="fa fa-cart-arrow-down" style="font-size: 30px;"></i></a>
            <img src="/images/menu.png" class="menu-icon" onclick="menuToggle()">
        </div>
    </div>

    <div class="small-container">
        <div class="row row-2">
            <h2>Models</h2>
            <select>
                <option><a href="<?php echo e(route('AllProducts')); ?>">All</a></option>
                <option>Medels</option>
                <option><a href="<?php echo e(route('poster')); ?>">Poster Images</a></option>
                <option>Clothes</option>
                <option>Accessories</option>
                <option>Sundry</option>
            </select>
        </div>

        <div class="row">
            <div class="col-4">
                <img src="/images/model/kaido/kaido.jpg">
                <h4>Kaido</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>650 THB</p>
            </div>
            <div class="col-4">
                <img src="../images/model/jinbe/jinbe.jpg">
                <h4>Jinbe</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>1300 THB</p>
            </div>
            <div class="col-4">
                <img src="/images/model/luffy3/luffy31.jpg">
                <h4>Luffy</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <p>900 THB</p>
            </div>
            <div class="col-4">
                <img src="/images/model/hancock/hancock.jpg">
                <h4>Hancock</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>550 THB</p>
            </div>
            <div class="col-4">
                <img src="/images/accessories/accessories1.jpg" height="240px">
                <h4>Necklace</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>50 THB</p>
            </div>
            <div class="col-4">
                <img src="/images/sundry/sundry3.jpg">
                <h4>Mattress set</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>400 THB</p>
            </div>
            <div class="col-4">
                <img src="/images/accessories/accessories9.jpg">
                <h4>Bangle</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>30 THB</p>
            </div>
            <div class="col-4">
                <img src="/images/sundry/bepo3/bepo31.jpg">
                <h4>ฺBepo</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <p>250 THB</p>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <img src="/images/model/model2.jpg">
                <h4>Kaido</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>1500 baht</p>
            </div>
            <div class="col-4">
                <img src="/images/model/model8.jpg">
                <h4>Kaido</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>1500 baht</p>
            </div>
            <div class="col-4">
                <img src="/images/model/kaido/kaido.jpg">
                <h4>Kaido</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
                </div>
                <p>1500 baht</p>
            </div>
            <div class="col-4">
                <img src="/images/model/model6.jpg">
                <h4>Kaido</h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p>1500 baht</p>
            </div>
        </div>

        <div class="page-btn">
            <span>1</span>
            <span>2</span>
            <span>3</span>
            <span>4</span>
            <span>&#8594;</span>
        </div>
    </div>

    <!-- ------ footer -------->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col-1">
                    <h3>Download Our App</h3>
                    <p>Download App for Android and ios mobile phone.</p>
                    <div class="app-logo">
                        <img src="/images/play-store.png">
                        <img src="/images/app-store.png">
                    </div>
                </div>
                <div class="footer-col-2">
                    <img src="/images/logo3.png">
                    <p>our Purpose Is To Sustainably Make the pleasure and <br>
                        Benefits of Sports Accessible to the Many.</p>
                </div>
                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                    <ul>
                        <li>Conpons</li>
                        <li>Blog Post</li>
                        <li>Return Policy</li>
                        <li>Join Affiliate</li>
                    </ul>
                </div>
                <div class="footer-col-4">
                    <h3>Follow</h3>
                    <ul>
                        <li>Facebook</li>
                        <li>Twitter</li>
                        <li>Instagram</li>
                        <li>Youtube</li>
                    </ul>
                </div>
            </div>
            <p class="copyright">Copyright 2020 - One Piece Shop</p>
        </div>
    </div>
</body>
<script src="js/index.js"></script>

</html><?php /**PATH C:\xampp\htdocs\OnePieceShop\OnePieceShop\resources\views/pages/AllProducts.blade.php ENDPATH**/ ?>