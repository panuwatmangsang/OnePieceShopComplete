<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

    <!-- css -->
    <link rel="stylesheet" href="/css/index2.css">

    <title>One Piece Shop</title>
</head>

<body>
    <nav>
        <div class="logo">
            <p>ONE PIECE SHOP</p>
        </div>
        <ul>
            <li><a class="active" href="#">หน้าหลัก</a></li>
            <li><a href="#">ขายสินค้าวันพีช</a></li>
            <li><a href="#">ช่วยเหลือ</a></li>
            <li><a href="#">ติดต่อ</a></li>
            <li><a href="#">ลงชื่อเข้าใช้</a></li>
        </ul>
    </nav>
    <section class="sec1">
        <div class="sidebar">
            <h1>หมวดหมู่</h1>
            <a href="#">โมเดล</a>
            <a href="#">รูปภาพ</a>
            <a href="#">เสื้อผ้า</a>
            <a href="#">เครื่องประดับ</a>
            <a href="#">อื่นๆ</a>
        </div>
        <div class="content">
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model1.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ ไคโด
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model2.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                   มังกี้ ดี ลูฟี่
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model3.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    โลโลโนอา โซโล
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model4.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ บิ๊กมัม
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model5.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ หนวดขาว
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model6.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ แซงก์คูส
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model7.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ แซงก์คูส
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model8.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    นกอมตะ มัลโก้
                </div>
            </div>
        </div>
    </section>
    <section class="sec2">
        <div class="content">
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model1.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ ไคโด
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model1.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ ไคโด
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model1.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ ไคโด
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model1.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ ไคโด
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model1.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ ไคโด
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model1.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ ไคโด
                </div>
            </div><div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model1.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ ไคโด
                </div>
            </div>
            <div class="gallery">
                <a href="#" target="#">
                    <img src="/images/model1.jpg" alt="model1" width="300" height="400">
                </a>
                <div class="desc">
                    สี่จักรพรรดิ ไคโด
                </div>
            </div>
        </div> 
    </section>
    <section class="sec3">
        <div class="main">
            <p>panuwat3</p>
        </div>
    </section>
    <section class="sec4">
        <div class="main">
            <p>panuwat4</p>
        </div>
    </section>
    <section class="sec5">
        <div class="main">
            <p>panuwat5</p>
        </div>
    </section>


</body>
<script src="js/index2.js"></script>

</html><?php /**PATH C:\xampp\htdocs\OnePieceShop\OnePieceShop\resources\views/index2.blade.php ENDPATH**/ ?>