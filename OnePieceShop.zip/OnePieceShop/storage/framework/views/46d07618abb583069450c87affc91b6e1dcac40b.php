<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- css -->
    <link rel="stylesheet" href="/css/index.css">

    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
    <div class="navbar">
        <ul>
            <li><a href="#">หน้าหลัก</a></li>
            <li><a href="#">ขายสินค้าวันพีช</a></li>
            <li><a href="#">ช่วยเหลือ</a></li>
            <li><a href="#">ติดต่อ</a></li>
            <li><a href="#">ลงชื่อเข้าใช้</a></li>
        </ul>
    </div>
    <!-- <div class="sidenav">
        <ul>
            <li><a href="#">โมเดล</a></li>
            <li><a href="#">รูปภาพ</a></li>
            <li><a href="#">เสื้อผ้า</a></li>
            <li><a href="#">เครื่องประดับ</a></li>
            <li><a href="#">อื่นๆ</a></li>
        </ul>
    </div> -->
    <div class="main">

    </div>
    <?php echo $__env->yieldContent('content'); ?>
</body>
<footer>
    <?php echo $__env->yieldContent('footer'); ?>
</footer>

</html><?php /**PATH C:\xampp\htdocs\OnePieceShop\OnePieceShop\resources\views/template.blade.php ENDPATH**/ ?>