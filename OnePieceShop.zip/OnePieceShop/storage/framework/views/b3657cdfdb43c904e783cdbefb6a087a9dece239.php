
<?php $__env->startSection('title','Welcome One Piece'); ?>
<?php $__env->startSection('content'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OnePieceShop\OnePieceShop\resources\views/top.blade.php ENDPATH**/ ?>